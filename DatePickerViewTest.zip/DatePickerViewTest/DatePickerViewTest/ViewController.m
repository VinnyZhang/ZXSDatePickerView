//
//  ViewController.m
//  DatePickerViewTest
//
//  Created by hesunZhang on 2018/1/12.
//  Copyright © 2018年 hesunZhang. All rights reserved.
//

#import "ViewController.h"
#import "ZXSDatePickerView.h"

@interface ViewController ()

@property (nonatomic,strong)UILabel *dateLabel;

@property (nonatomic,strong)ZXSDatePickerView *datePickerView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _dateLabel = [[UILabel alloc] init];
    [self.view addSubview:_dateLabel];
    [_dateLabel setBackgroundColor:[UIColor grayColor]];
    [_dateLabel setTextColor:[UIColor blackColor]];
    [_dateLabel setFont:[UIFont systemFontOfSize:18]];
    [_dateLabel setUserInteractionEnabled:YES];
    
    [_dateLabel setFrame:CGRectMake(100, 200, 200, 50)];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dateClick)];
    [_dateLabel addGestureRecognizer:tap];

    
}

-(void)dateClick
{
    [self.datePickerView showDatePickerBirthdayWithDate:[NSDate date] minDate:nil maxDate:nil block:^(NSDate *selectDate) {
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy-MM-dd"];
        _dateLabel.text = [formatter stringFromDate:selectDate];
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (ZXSDatePickerView *)datePickerView
{
    if(!_datePickerView){
        _datePickerView = [[ZXSDatePickerView alloc] init];
    }
    return _datePickerView;
}

@end

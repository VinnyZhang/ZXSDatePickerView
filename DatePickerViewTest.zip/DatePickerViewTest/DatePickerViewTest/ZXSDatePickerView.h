//
//  DatePickerBirthday.h
//  Mocha_UserSide
//
//  Created by hesunZhang on 2017/11/22.
//  Copyright © 2017年 hesunZhang. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^SelectDateBlock)(NSDate  *selectDate);

/**
 日期选择控件
 */
@interface ZXSDatePickerView : UIView


/**
 展示日期选择控件

 @param currentDate 当前选中日期
 @param minDate 日期控件中展示的的最小日期
 @param maxDate 日期控件中展示的最大日期
 @param block 选中日期回调
 */
- (void)showDatePickerBirthdayWithDate:(NSDate *)currentDate minDate:(NSDate *)minDate maxDate:(NSDate *)maxDate block:(SelectDateBlock)block;

@end

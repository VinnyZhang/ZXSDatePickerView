//
//  DatePickerBirthday.m
//  ZXSDatePickerViewTest
//
//  Created by hesunZhang on 2017/11/22.
//  Copyright © 2017年 hesunZhang. All rights reserved.
//

#import "ZXSDatePickerView.h"
#import <Masonry/Masonry.h>

#define SCREENSIZE_LATTE ([UIScreen mainScreen].bounds.size)
#define SCREENSCALE_LATTE ([UIScreen mainScreen].scale)

#define SCREENWIDTH (SCREENSIZE_LATTE.width)

#define RATE_375_H ((SCREENWIDTH >= 375.f) ? (SCREENWIDTH/375.f) : 1) //iphone6UI效果图向下适配［iphone5］的比例
#define fitI6_H(size) (int)(size*RATE_375_H)//基于iphone6的效果图进行适配的尺寸(int) 向上适配
#define RATE_375 (SCREENWIDTH/375.f)//iphone6UI效果图适配的比例


#define fitI6(size) (int)(size*RATE_375)//基于iphone6的效果图进行适配的尺寸(int)



@interface ZXSDatePickerView()

/**
 触控视图
 */
@property (nonatomic,strong) UIControl *control;

/**
 日期选择视图
 */
@property (nonatomic,strong) UIView *datePickerView;

/**
 日期选择头部视图
 */
@property(nonatomic,strong) UIView *headerView;

/**
 取消按钮
 */
@property (nonatomic,strong) UIButton *cancelButton;

/**
 确认按钮
 */
@property (nonatomic,strong) UIButton *sureButton;

/**
 日历
 */
@property (nonatomic,strong) UIDatePicker *datePicker;

@property (nonatomic,strong) UIView *topLine;

@property (nonatomic,strong) UIView *bottomLine;

/**
 选中日期回调
 */
@property (nonatomic,copy) SelectDateBlock myBlock;

@end

@implementation ZXSDatePickerView

#pragma mark - construction methdos -

- (instancetype)init
{
    if(self = [super init]){
        [self initInterface];
    }
    return self;
}

#pragma mark - outside methods -

/**
 展示日期选择控件
 
 @param currentDate 当前选中日期
 @param minDate 日期控件中展示的的最小日期
 @param maxDate 日期控件中展示的最大日期
 @param block 选中日期回调
 */
- (void)showDatePickerBirthdayWithDate:(NSDate *)currentDate minDate:(NSDate *)minDate maxDate:(NSDate *)maxDate block:(SelectDateBlock)block{
    
    self.myBlock = block;
    
    if(currentDate == nil){
        currentDate = [NSDate dateWithTimeIntervalSinceNow:(-3600*24*365*28)];
    }
    if(minDate == nil){
        minDate = [NSDate dateWithTimeIntervalSinceNow:(-3600*24*365*80)];
    }
    if(maxDate == nil){
        maxDate = [NSDate date];
    }
    self.datePicker.maximumDate = maxDate;
    self.datePicker.minimumDate = minDate;
    [self.datePicker setDate:currentDate animated:NO];
    
    self.hidden = NO;
    
    [self.datePickerView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.mas_bottom).offset(fitI6_H(270));
    }];
    [self layoutIfNeeded];
    
    [UIView animateWithDuration:0.3 animations:^{
        [self.datePickerView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.mas_bottom).offset(0);
        }];
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        
    }];
    
}

#pragma mark - internal method -

/**
 初始化子视图
 */
- (void)initInterface
{
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    [self mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo([UIApplication sharedApplication].keyWindow);
    }];
    self.hidden = YES;
    self.backgroundColor = [UIColor clearColor];
    
    [self.control mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
    [self.datePickerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self);
        make.bottom.equalTo(self.mas_bottom).offset(0);
        make.height.mas_equalTo(fitI6_H(270));
    }];
    
    [self.headerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.equalTo(self.datePickerView);
        make.height.mas_equalTo(fitI6_H(50));
    }];
    
    [self.topLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.equalTo(self.headerView);
        make.height.mas_equalTo(0.6);
    }];
    
    [self.bottomLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.headerView);
        make.height.mas_equalTo((0.6));
    }];
    
    [self.cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(fitI6_H(40));
        make.height.mas_equalTo(fitI6_H(25));
        make.left.equalTo(self.headerView.mas_left).offset(fitI6(15));
        make.centerY.equalTo(self.headerView);
    }];
    
    [self.sureButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(fitI6_H(40));
        make.height.mas_equalTo(fitI6_H(25));
        make.right.equalTo(self.headerView.mas_right).offset(-fitI6(15));
        make.centerY.equalTo(self.headerView);
    }];
    
    [self.datePicker mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.datePickerView);
        make.top.equalTo(self.headerView.mas_bottom).offset(0);
    }];
    
    [self.cancelButton addTarget:self action:@selector(cancelClick) forControlEvents:UIControlEventTouchUpInside];
    
    [self.sureButton addTarget:self action:@selector(sureClick) forControlEvents:UIControlEventTouchUpInside];
    
    [self.control addTarget:self action:@selector(hideSelfClick) forControlEvents:UIControlEventTouchUpInside];
    
}

/*隐藏*/
-(void)hideSelfClick
{
    [UIView animateWithDuration:0.3 animations:^{
        [self.datePickerView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.mas_bottom).offset(fitI6_H(270));
        }];
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        self.hidden = YES;
    }];
    
    
}
/*
 取消
 */
-(void)cancelClick
{
    [self hideSelfClick];
}

/**
 确认按钮点击事件
 */
- (void)sureClick{
    if (self.myBlock) {
        //        typeBlock([myPickerView selectedRowInComponent:0]);
        self.myBlock(self.datePicker.date);
    }
    [self hideSelfClick];
}

#pragma mark - lazy loading -

- (UIControl *)control
{
    if(!_control){
        _control = [[UIControl alloc] init];
        _control.backgroundColor = [UIColor clearColor];
        [self addSubview:_control];
    }
    return _control;
}

- (UIView *)datePickerView
{
    if(!_datePickerView){
        _datePickerView = [[UIView alloc] init];
        [_datePickerView setBackgroundColor:[UIColor whiteColor]];
        [self addSubview:_datePickerView];
    }
    return _datePickerView;
}

- (UIView *)headerView
{
    if(!_headerView){
        _headerView = [[UIView alloc] init];
        [_headerView setBackgroundColor:[UIColor whiteColor]];
        [self.datePickerView addSubview:_headerView];
    }
    return _headerView;
}

- (UIButton *)cancelButton
{
    if(!_cancelButton){
        _cancelButton = [[UIButton alloc] init];
        [_cancelButton setBackgroundColor:[UIColor whiteColor]];
        [_cancelButton setTitle:@"取消" forState:UIControlStateNormal];
        [_cancelButton setTitleColor:[UIColor colorWithRed:85/255.0 green:137/255.0 blue:254/255.0 alpha:1.0] forState:UIControlStateNormal];
        [_cancelButton.titleLabel setFont:[UIFont fontWithName:@"PingFangSC-Regular" size:fitI6_H(18)]];
        [self.headerView addSubview:_cancelButton];
    }
    return _cancelButton;
}

- (UIButton *)sureButton
{
    if(!_sureButton){
        _sureButton = [[UIButton alloc] init];
        [_sureButton setBackgroundColor:[UIColor whiteColor]];
        [_sureButton setTitle:@"确认" forState:UIControlStateNormal];
        [_sureButton setTitleColor:[UIColor colorWithRed:85/255.0 green:137/255.0 blue:254/255.0 alpha:1.0] forState:UIControlStateNormal];
        [_sureButton.titleLabel setFont:[UIFont fontWithName:@"PingFangSC-Regular" size:fitI6_H(18)]];
        [self.headerView addSubview:_sureButton];
    }
    return _sureButton;
}

- (UIDatePicker *)datePicker
{
    if(!_datePicker){
        _datePicker = [[UIDatePicker alloc] init];
        _datePicker.datePickerMode = UIDatePickerModeDate;
        [self.datePickerView addSubview:_datePicker];
    }
    return _datePicker;
    
}

- (UIView *)topLine
{
    if(!_topLine){
        _topLine = [[UIView alloc] init];
        [_topLine setBackgroundColor:[UIColor colorWithRed:229/255.0 green:229/255.0 blue:229/255.0 alpha:1.0]];
        [self.headerView addSubview:_topLine];
    }
    return _topLine;
}

- (UIView *)bottomLine
{
    if(!_bottomLine){
        _bottomLine = [[UIView alloc] init];
        [_bottomLine setBackgroundColor:[UIColor colorWithRed:229/255.0 green:229/255.0 blue:229/255.0 alpha:1.0]];
        [self.headerView addSubview:_bottomLine];
    }
    return _bottomLine;
}

@end
